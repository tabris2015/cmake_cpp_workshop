#include <iostream>
#include "complex.h"

int main(int argc, char const *argv[])
{
    /* code */
    Complex c1(1,1);
    Complex c2(3,4);

    std::cout << c2.abs() << "\n";
    std::cout << c1.arg() << "\n";
    auto suma = (c1 + c2);
    std::cout <<"(" << suma.real() << "," <<suma.imag() << ")\n";
    auto mult = (c1 * c2);
    std::cout <<"(" << mult.real() << "," <<mult.imag() << ")\n";
    auto rot = polar(1, 0.78539816339);
    auto rotado = mult * rot;
    std::cout <<"(" << rotado.real() << "," <<rotado.imag() << ")\n";
    
    return 0;
}
